import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import mysql.connector
from datetime import datetime
import cv2
import pandas as pd
import os
import csv

class FaceRecognitionSystem:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Face Recognition System")

        title_lbl = tk.Label(self.root, text="FACE RECOGNITION", font=("times new roman", 35, "bold"), bg="white", fg="green")
        title_lbl.place(x=0, y=0, width=1530, height=45)

        # Load and resize images for display
        img_top = Image.open(r"images/face-recog-1024x678.jpg")
        img_top = img_top.resize((650, 700), Image.LANCZOS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        img_bottom = Image.open(r"images/facial_recognition_system_identification_digital_id_security_scanning_thinkstock_858236252_3x3-100740902-large.webp")
        img_bottom = img_bottom.resize((950, 700), Image.LANCZOS)
        self.photoimg_bottom = ImageTk.PhotoImage(img_bottom)

        # Display images
        f_lbl1 = tk.Label(self.root, image=self.photoimg_top)
        f_lbl1.place(x=0, y=55, width=650, height=700)

        f_lbl2 = tk.Label(self.root, image=self.photoimg_bottom)
        f_lbl2.place(x=650, y=55, width=950, height=700)

        # Button for face recognition
        b1_1 = tk.Button(self.root, text="Face Recognition", command=self.face_recog, cursor="hand2", font=("times new roman", 18, "bold"), bg="dark green", fg="white")
        b1_1.place(x=1020, y=680, width=200, height=40)

    def mark_attendance(self, i, r, n, d):
        file_path = "CS6.csv"
        
        data = []
        with open(file_path, 'r') as f:
            reader = csv.reader(f)
            for row in reader:
                # Ensure rows have the expected number of columns
                if len(row) == 7:  # Adjust the number of columns as needed
                    data.append(row)
        
        # Convert to DataFrame
        df = pd.DataFrame(data, columns=['i', 'r', 'n', 'd', 'Time', 'Date', 'Status'])
        
        # Drop duplicates
        df.drop_duplicates(inplace=True)
        # Clean input values
        i = self.clean_value(i)
        r = self.clean_value(r)
        n = self.clean_value(n)
        d = self.clean_value(d)

        name_list = df['i'].tolist()  # Adjust based on the actual column name
        
        # Check if the names are not already in the name_list
        if i not in name_list and r not in name_list and n not in name_list and d not in name_list:
            now = datetime.now()
            d1 = now.strftime("%d/%m/%Y")
            dtString = now.strftime("%H:%M:%S")
            
            # Append the new attendance record to the DataFrame
            new_record = pd.DataFrame({
               'i': [i],
                'r': [r],
                'n': [n],
                'd': [d],
                'Time': [dtString],
                'Date': [d1],
                'Status': [f'Present{i}']
            })
            
            df = pd.concat([df, new_record], ignore_index=True)

            # Drop rows with any None values across all columns
            df_filtered = df.dropna()

            
            # Save the updated DataFrame back to the CSV file
            df_filtered.to_csv(file_path, index=False)

    def clean_value(self, value):
        if isinstance(value, str) and value.startswith("('") and value.endswith("',)"):
            return value[2:-3]
        return value

    def face_recog(self):
        def draw_boundary(img, classifier, scaleFactor, minNeighbors, color, text, clf):
            gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            features = classifier.detectMultiScale(gray_image, scaleFactor, minNeighbors)

            for (x, y, w, h) in features:
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 3)
                id, predict = clf.predict(gray_image[y:y + h, x:x + w])
                confidence = int((100 * (1 - predict / 300)))

                if confidence > 77:
                    conn = mysql.connector.connect(host="localhost", username="root", password="priya#####2004", database="face_recognizer")
                    my_cursor = conn.cursor()

                    my_cursor.execute("select Name from student where Student_id=" + str(id))
                    n = my_cursor.fetchone()
                    n = self.clean_value(str(n))

                    my_cursor.execute("select Roll from student where Student_id=" + str(id))
                    r = my_cursor.fetchone()
                    r = self.clean_value(str(r))

                    my_cursor.execute("select Dep from student where Student_id=" + str(id))
                    d = my_cursor.fetchone()
                    d = self.clean_value(str(d))

                    my_cursor.execute("select Student_id from student where Student_id=" + str(id))
                    i = my_cursor.fetchone()
                    i = self.clean_value(str(i))

                    if None in (i, r, n, d):
                        continue  # Skip if any critical value is None
                    
                    cv2.putText(img, f"ID: {i}", (x, y - 75), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"Roll: {r}", (x, y - 55), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"Name: {n}", (x, y - 30), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"Department: {d}", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)

                    # Mark attendance
                    self.mark_attendance(i, r, n, d)
                else:
                    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 3)
                    cv2.putText(img, "Unknown Face", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)

            return img

        faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
        clf = cv2.face.LBPHFaceRecognizer_create()
        clf.read("classifier.xml")

        video_cap = cv2.VideoCapture(0)

        while True:
            ret, img = video_cap.read()
            img = draw_boundary(img, faceCascade, 1.1, 10, (255, 25, 255), "Face", clf)
            cv2.imshow("Welcome to Face Recognition", img)

            if cv2.waitKey(1) == 13:  # Press Enter to exit
                break

        video_cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    root = tk.Tk()
    obj = FaceRecognitionSystem(root)
    root.mainloop()
