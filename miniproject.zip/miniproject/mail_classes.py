from email.mime.text import MIMEText as text
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import smtplib
import os

class Sendmail:
    def __init__(self,department,semester):
        self.department = department
        self.semester = semester

    def send_mail(self,Department, Semester):
        emailFetch = open("Emailidpass.txt",'r')
        GetIdPass = (emailFetch.readline()).split("#")
        emailFetch.close()

        server = smtplib.SMTP('smtp.gmail.com',587)

        #secures the server and mails
        server.starttls()

        #username and password for admin
        #remember to change to your mail
        server.login(GetIdPass[0],GetIdPass[1])

        #checking for the student list file
        if Department == "Computer Science":
            if Semester == "6":
                namelist = "cse6.txt"
                maillist = "cse6m.txt"
                fileName = "CS6.csv"
            elif Semester == "4":
                namelist = "cse4.txt"
                maillist = "cse4m.txt"
                fileName = "cse4.xlsx"
            else:
                # Handle invalid semester value
                print(f"Invalid semester value: {Semester}")
                return

        elif Department == "Aeronautical":
            if Semester == "6":
                namelist = "ae6.txt"
                maillist = "ae6m.txt"
                fileName = "ae6.xlsx"
            elif Semester == "4":
                namelist = "ae4.txt"
                maillist = "ae4m.txt"
                fileName = "ae4.xlsx"
            else:
                # Handle invalid semester value
                print(f"Invalid semester value: {Semester}")
                return

        elif Department == "Electronics and communication":
            if Semester == "6":
                namelist = "ece6.txt"
                maillist = "ece6m.txt"
                fileName = "ece6.xlsx"
            elif Semester == "4":
                namelist = "ece4.txt"
                maillist = "ece4m.txt"
                fileName = "ece4.xlsx"
            else:
                # Handle invalid semester value
                print(f"Invalid semester value: {Semester}")
                return

        elif Department == "Agriculture":
            if Semester == "6":
                namelist = "ag6.txt"
                maillist = "ag6m.txt"
                fileName = "ag6.xlsx"
            elif Semester == "4":
                namelist = "ag4.txt"
                maillist = "ag4m.txt"
                fileName = "ag4.xlsx"
            else:
                # Handle invalid semester value
                print(f"Invalid semester value: {Semester}")
                return
        else:
            # Handle invalid department value
            print(f"Invalid department value: {Department}")
            return
        
        #students name list
        studentname = open(namelist)
        listofnames = studentname.readlines()

        #students emails corresponding to names
        studentemail = open(maillist)
        listofemail = studentemail.readlines()

        #attachment size reading
        filePath = "./mailpart/" + fileName

        #calculating the size of attachment
        #fileSize = os.path.getsize(filePath)/ 10**6

        def sent():            
            for i in range(0,len(listofemail)):

                msg = MIMEMultipart()

                #To add subject to the mail 
                msg['Subject'] = 'Student Attendence copy-6th sem'
                msg.attach(text(f"Hi {listofnames[i]},\n\nplease find your attendence attachment below.\n\n Regards College"))

                #attaching the excel file
                fileAttach = open(fileName, "rb")
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(fileAttach.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f"attachment; filename= {fileName}")
                msg.attach(part)

                #sends the gamil to recepint
                server.sendmail(GetIdPass[0],listofemail[i], msg.as_string())
                
        sent()
        server.quit()
    pass
