from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from mail_classes import Sendmail


class Email:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recogniton system")

         #selected values variables
        self.var_dep = StringVar()
        self.var_sem = StringVar()

        #first image
        img1 = Image.open(r"images\img.jpg")
        img1=img1.resize((500,130),Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img1)

        f_lbl=Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=0,width=500,height=130)

        #second image
        img2 = Image.open(r"images\image2.jpg")
        img2=img2.resize((500,130),Image.Resampling.LANCZOS)
        self.photoimg1 = ImageTk.PhotoImage(img2)

        f_lbl=Label(self.root,image=self.photoimg1)
        f_lbl.place(x=500,y=0,width=500,height=130)

        #third image
        img3 = Image.open(r"images\image3.jpg")
        img3=img3.resize((500,130),Image.Resampling.LANCZOS)
        self.photoimg2 = ImageTk.PhotoImage(img3)

        f_lbl=Label(self.root,image=self.photoimg2)
        f_lbl.place(x=1000,y=0,width=500,height=130)

        #bg image
        img4 = Image.open(r"images\background.jpg")
        img4=img4.resize((1530,710),Image.Resampling.LANCZOS)
        self.photoimg3 = ImageTk.PhotoImage(img4)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(x=0,y=135,width=1530,height=710)

        title_lbl = Label(bg_img,text="FACE RECOGNITION ATTENDENCE SYSTEM SOFTWARE",font=("times new roman", 35, "bold"),bg="white",fg="red")
        title_lbl.place(x=0,y=5,width=1590,height=45)

        main_frame = Frame(bg_img,bd=2)
        main_frame.place(x=5,y=55,width=1500,height=600)

        #center lable frame

        Center_frame = LabelFrame(main_frame,bd=5,relief=RIDGE,text="Email Block",font=("times new roman",30,"italic"))
        Center_frame.place(x=400,y=10,width=720,height=500)

        #dept selction combobox
        dep_lable = Label(Center_frame,text="Department", font=("times new roman", 15, "bold"))
        dep_lable.grid(row=0,column=0,padx=20, pady=20)
    
        dep_combo = ttk.Combobox(Center_frame,textvariable=self.var_dep,font=("times new roman", 15, "bold"),width=25,state="readonly")
        dep_combo["values"] = ("Select Department","Computer Science","Aeronautical","Electronic and communication","Agriculture")
        dep_combo.current(0)
        dep_combo.grid(row=0,column=1, padx=5,pady=20)

        #sem lable frame
        sem_lable = Label(Center_frame,text="Semester", font=("times new roman", 15, "bold"))
        sem_lable.grid(row=1,column=0,padx=20, pady=20)
    
        sem_combo = ttk.Combobox(Center_frame,textvariable=self.var_sem,font=("times new roman", 15, "bold"),width=25,state="readonly")
        sem_combo["values"] = ("Select Semester","1","2","3","4","5","6","7","8")
        sem_combo.current(0)
        sem_combo.grid(row=1,column=1, padx=5,pady=20)

        #button frame

        btn_frame = Frame(Center_frame,bd=2,relief=RIDGE)
        btn_frame.place(x=30,y=300,width=655,height=58)

        save_btn = Button(btn_frame,command=self.send_data,text="Send",width=40,font=("times new roman",20,"bold"),bg="light blue",fg="black")
        save_btn.grid(row=3,column=0)


#==========function buttn=======

    def send_data(self):
        if self.var_dep.get()=="Select Department" or self.var_sem.get()=="Select Semester":
            messagebox.showerror("Error","all fields are required",parent= self.root)
        else :
            messagebox.showinfo("info","Mail sent Successfully!")
        sendmail = Sendmail(self.var_dep.get(),self.var_sem.get())
        sendmail.send_mail(self.var_dep.get(),self.var_sem.get())
        

            

if __name__ == "__main__":
    root=Tk()
    obj = Email(root)
    root.mainloop()